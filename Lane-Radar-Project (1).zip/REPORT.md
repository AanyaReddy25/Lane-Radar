
# Lane Radar — Model Evaluation Report

## 1. Evaluation Method

Lane Radar evaluates pretrained object detection models for supermarket
checkout queue person counting.

The evaluation dataset contains 20 supermarket checkout images.
Each image has a manually annotated ground-truth person count.

The following models were evaluated:
- YOLOv8n
- YOLO11n
- Faster R-CNN ResNet50 FPN

All models were evaluated using the same dataset.

### Evaluation Metrics

- MAE: Measures the average absolute difference between predicted
  and actual person counts.
- RMSE: Penalizes larger prediction errors.
- Exact Match: Percentage of images where predicted count equals
  actual count.
- Within ±1: Percentage of images where prediction differs by
  at most one person.
- Average Inference Time: Average time taken to process one image.

MAE was selected as the primary metric because the project focuses
on estimating the number of people in checkout queues.

## 2. Model Comparison

| Model | MAE | RMSE | Exact Match (%) | Within ±1 (%) | Inference Time (s) |
|---|---:|---:|---:|---:|---:|
| YOLOv8n | 2.60 | 3.421 | 20.0 | 45.0 | 0.3191 |
| YOLO11n | 2.40 | 2.966 | 15.0 | 30.0 | 0.1209 |
| Faster R-CNN ResNet50 FPN | 7.45 | 9.521 | 5.0 | 20.0 | 0.1664 |

### Selected Model

YOLO11n was selected for further development because it achieved
the lowest MAE among the evaluated models and provided fast inference.

The selected model evaluation recorded:
- MAE: 2.40
- RMSE: 2.966
- Exact Match: 15%
- Within ±1 Person: 30%
- Average Inference Time: 0.1164 seconds

## 3. Error Analysis

Three prediction errors will be examined:

1. Images with significant overcounting.
2. Images with significant undercounting.
3. Images containing background people, overlapping people,
   or partially visible people.

Possible reasons for errors include occlusion, image quality,
overlapping people, and people appearing small in the image.

## 4. Limitations

The dataset contains only 20 images. Therefore, the results may not
generalize to every supermarket environment.

The current implementation estimates the number of visible people.
It does not yet estimate shopping basket sizes or actual checkout
waiting times.

## 5. Conclusion

YOLO11n provides a promising starting point for Lane Radar.
Further improvements may include a larger dataset, fine-tuning,
and checkout-time estimation based on queue length and basket load.


## 6. Detailed Error Analysis

The three largest YOLO11n counting errors were examined.

### Example 1: Boston Public Library Image
- Actual people: 22
- Predicted people: 16
- Absolute error: 6
- Observation: The model undercounted the people in the image.
  Possible reasons include overlapping people and occlusion.

### Example 2: IMG_2209.webp
- Actual people: 12
- Predicted people: 6
- Absolute error: 6
- Observation: The model undercounted the visible people.
  The crowded scene may have made person detection difficult.

### Example 3: 2ADCGEDSPFFCVKR2KZTFNE3P6M.jpg
- Actual people: 2
- Predicted people: 6
- Absolute error: 4
- Observation: The model overcounted the people.
  One possible reason is that checkout staff and customers
  may have been counted differently during manual annotation.

### Error Analysis Conclusion

YOLO11n showed both undercounting and overcounting.
Occlusion, crowded scenes, and inconsistent counting scope
may contribute to the errors. A larger dataset and consistent
annotation rules could improve evaluation reliability.
