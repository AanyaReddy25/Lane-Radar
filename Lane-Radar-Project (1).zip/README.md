
# Lane Radar
## Smart Queue and Checkout Time Estimation

Lane Radar is a computer vision project that estimates the number
of people waiting at supermarket checkout lanes.

### Models Evaluated
- YOLOv8n
- YOLO11n
- Faster R-CNN ResNet50 FPN

### Evaluation Metrics
- Mean Absolute Error (MAE)
- Root Mean Squared Error (RMSE)
- Exact Match Accuracy
- Accuracy Within ±1 Person
- Average Inference Time

### Dataset
The evaluation dataset contains 20 supermarket checkout images
with manually annotated ground-truth person counts.

### Technologies
Python, Google Colab, PyTorch, Ultralytics YOLO, OpenCV

### Running the Project
Run the notebook cells in order to evaluate the models
and compare their performance.
